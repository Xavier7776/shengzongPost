import Image from 'next/image'
import Link from 'next/link'
import { Github, Search, Mail } from 'lucide-react'

export default function DarkFooter() {
  return (
    <footer
      className="py-16 text-center relative z-10"
      style={{ borderTop: '1px solid rgba(255,255,255,0.05)' }}
    >
      <style>{`
        .dark-footer-icon { color: rgba(255,255,255,0.25); transition: color 0.2s; }
        .dark-footer-icon:hover { color: #c8a97e; }
      `}</style>
      <div className="max-w-6xl mx-auto px-6">
        <div className="flex items-center justify-center gap-2.5 mb-8">
          <Image src="/logo.png" alt="MindStack" width={32} height={32} className="w-8 h-8 rounded-full" />
          <h2 className="text-2xl font-black tracking-tighter" style={{ color: '#e8e8e8' }}>
            Mind<span style={{ color: '#c8a97e' }}>Stack</span>
          </h2>
        </div>
        <div className="flex justify-center space-x-6 mb-8">
          <a
            href="https://github.com/Xavier7776"
            target="_blank"
            rel="noopener noreferrer"
            className="dark-footer-icon"
            aria-label="GitHub"
          >
            <Github className="w-5 h-5" />
          </a>
          <a
            href="https://www.bing.com"
            target="_blank"
            rel="noopener noreferrer"
            className="dark-footer-icon"
            aria-label="Bing"
          >
            <Search className="w-5 h-5" />
          </a>
          <Link
            href="/projects#contact"
            className="dark-footer-icon"
            aria-label="联系我"
          >
            <Mail className="w-5 h-5" />
          </Link>
        </div>
        <p
          className="text-xs font-bold tracking-[0.2em] uppercase"
          style={{ color: 'rgba(255,255,255,0.12)' }}
        >
          © {new Date().getFullYear()} MindStack. Built with Precision.
        </p>
      </div>
    </footer>
  )
}

'use client'

import { useEffect, useRef, useCallback } from 'react'
import * as THREE from 'three'

interface HeartCrystalProps {
  burst?: boolean
  onBurstComplete?: () => void
  mouseX?: number
  mouseY?: number
}

// ─────────────────────────────────────────────────────────────
// 入场动画三阶段时间轴（单位：秒）
//   Phase 0 – 粒子随机散布，静止 0.3s（给 mount 留余地）
//   Phase 1 – lerp 飞向心形轮廓目标点       0.0 ~ 1.6s
//   Phase 2 – 粒子隐退，实体心形淡入        1.6 ~ 2.4s
//   Phase 3 – 正常 idle 状态
// ─────────────────────────────────────────────────────────────
const PHASE1_START = 0.3   // 粒子开始移动
const PHASE1_END   = 1.9   // 粒子到位
const PHASE2_END   = 2.7   // 实体完全可见

export default function HeartCrystal({
  burst = false,
  onBurstComplete,
  mouseX = 0,
  mouseY = 0,
}: HeartCrystalProps) {
  const mountRef = useRef<HTMLDivElement>(null)
  const sceneRef = useRef<{
    renderer: THREE.WebGLRenderer
    scene: THREE.Scene
    camera: THREE.PerspectiveCamera
    heartGroup: THREE.Group
    burstParticles: THREE.Points | null
    animFrame: number
    isBursting: boolean
    burstStartTime: number
    mouseX: number
    mouseY: number
    lights: THREE.PointLight[]
    sparks: THREE.Points
    // 入场相关
    introParticles: THREE.Points | null
    introStartTime: number
    introPhase: 0 | 1 | 2 | 3   // 0=待机, 1=飞行, 2=消融, 3=完成
  } | null>(null)

  // ── 心形参数方程 ─────────────────────────────────────────
  const heartPoint = useCallback((t: number, scale: number): [number, number] => {
    const x = scale * 16 * Math.pow(Math.sin(t), 3)
    const y = scale * (
      13 * Math.cos(t) -
      5  * Math.cos(2 * t) -
      2  * Math.cos(3 * t) -
          Math.cos(4 * t)
    )
    return [x, y]
  }, [])

  const buildHeartShape = useCallback((scale: number) => {
    const shape = new THREE.Shape()
    const N = 256
    for (let i = 0; i <= N; i++) {
      const t = (i / N) * Math.PI * 2
      const [x, y] = heartPoint(t, scale)
      i === 0 ? shape.moveTo(x, y) : shape.lineTo(x, y)
    }
    return shape
  }, [heartPoint])

  const buildHeartGeo = useCallback((scale: number) => {
    const geo = new THREE.ExtrudeGeometry(buildHeartShape(scale), {
      depth: 0.30,
      bevelEnabled: true,
      bevelThickness: 0.10,
      bevelSize: 0.07,
      bevelSegments: 16,
      curveSegments: 80,
    })
    geo.center()
    return geo
  }, [buildHeartShape])

  // ── 爆炸粒子（原有功能保留）────────────────────────────
  const createBurstParticles = useCallback(() => {
    const count = 1000
    const positions  = new Float32Array(count * 3)
    const velocities = new Float32Array(count * 3)
    const colors     = new Float32Array(count * 3)

    const palette: THREE.Color[] = [
      new THREE.Color('#C4785A'),
      new THREE.Color('#E8849C'),
      new THREE.Color('#F2A98A'),
      new THREE.Color('#FFDDD5'),
      new THREE.Color('#FF6B88'),
      new THREE.Color('#ffffff'),
    ]

    for (let i = 0; i < count; i++) {
      const theta = Math.random() * Math.PI * 2
      const phi   = Math.acos(2 * Math.random() - 1)
      const r     = 0.2 + Math.random() * 0.8
      positions[i*3]   = r * Math.sin(phi) * Math.cos(theta)
      positions[i*3+1] = r * Math.sin(phi) * Math.sin(theta)
      positions[i*3+2] = r * Math.cos(phi)

      const speed = 0.012 + Math.random() * 0.055
      velocities[i*3]   = (Math.random() - 0.5) * speed * 3.5
      velocities[i*3+1] = (Math.random() * 0.7 + 0.15) * speed * 3
      velocities[i*3+2] = (Math.random() - 0.5) * speed * 3

      const c = palette[Math.floor(Math.random() * palette.length)]
      colors[i*3] = c.r; colors[i*3+1] = c.g; colors[i*3+2] = c.b
    }

    const geo = new THREE.BufferGeometry()
    geo.setAttribute('position', new THREE.BufferAttribute(positions, 3))
    geo.setAttribute('color',    new THREE.BufferAttribute(colors,    3))
    geo.userData.velocities = velocities

    const mat = new THREE.PointsMaterial({
      size: 0.042, vertexColors: true,
      transparent: true, opacity: 1, sizeAttenuation: true,
    })
    return new THREE.Points(geo, mat)
  }, [])

  // ── 入场粒子：随机散布 → 心形轮廓目标 ──────────────────
  const createIntroParticles = useCallback((heartScale: number) => {
    const OUTLINE_COUNT = 600   // 轮廓粒子
    const FILL_COUNT    = 400   // 填充粒子（轮廓内随机采样）
    const count = OUTLINE_COUNT + FILL_COUNT

    const positions = new Float32Array(count * 3)  // 当前位置（随机）
    const targets   = new Float32Array(count * 3)  // 目标位置（心形上）
    const colors    = new Float32Array(count * 3)

    const palette: THREE.Color[] = [
      new THREE.Color('#FF2255'),
      new THREE.Color('#FF6B88'),
      new THREE.Color('#E8849C'),
      new THREE.Color('#FFDDD5'),
      new THREE.Color('#ffffff'),
      new THREE.Color('#C4785A'),
    ]

    // 散布半径（屏幕外围）
    const spreadR = 4.5

    // ── 轮廓粒子：沿心形曲线均匀采样 ──
    for (let i = 0; i < OUTLINE_COUNT; i++) {
      // 随机起始位置（球面随机，离心较远）
      const theta = Math.random() * Math.PI * 2
      const phi   = Math.acos(2 * Math.random() - 1)
      const r     = spreadR * (0.6 + Math.random() * 0.4)
      positions[i*3]   = r * Math.sin(phi) * Math.cos(theta)
      positions[i*3+1] = r * Math.sin(phi) * Math.sin(theta)
      positions[i*3+2] = r * Math.cos(phi) * 0.5

      // 目标：心形轮廓上的点
      const t = (i / OUTLINE_COUNT) * Math.PI * 2
      const [hx, hy] = heartPoint(t, heartScale)
      targets[i*3]   = hx
      targets[i*3+1] = hy
      targets[i*3+2] = (Math.random() - 0.5) * 0.15  // 轻微 z 抖动

      const c = palette[Math.floor(Math.random() * palette.length)]
      colors[i*3] = c.r; colors[i*3+1] = c.g; colors[i*3+2] = c.b
    }

    // ── 填充粒子：心形内部随机采样（rejection sampling）──
    let filled = 0
    let attempt = 0
    const maxAttempts = FILL_COUNT * 30
    while (filled < FILL_COUNT && attempt < maxAttempts) {
      attempt++
      const tx = (Math.random() * 2 - 1) * heartScale * 16
      const ty = (Math.random() * 2 - 1) * heartScale * 16

      // 判断点是否在心形内：用射线法近似
      // 心形公式：(x²+y²-1)³ - x²y³ ≤ 0，但我们用参数化心形，改用简单判断
      // 转换到归一化空间做近似测试
      const nx = tx / (heartScale * 16)
      const ny = ty / (heartScale * 13)
      // 心形内部判断（参数化近似）
      const inside = Math.pow(nx * nx + ny * ny - 1, 3) - nx * nx * ny * ny * ny <= 0.02
      if (!inside) continue

      const idx = OUTLINE_COUNT + filled
      const theta = Math.random() * Math.PI * 2
      const phi   = Math.acos(2 * Math.random() - 1)
      const r     = spreadR * (0.5 + Math.random() * 0.5)
      positions[idx*3]   = r * Math.sin(phi) * Math.cos(theta)
      positions[idx*3+1] = r * Math.sin(phi) * Math.sin(theta)
      positions[idx*3+2] = r * Math.cos(phi) * 0.5

      targets[idx*3]   = tx
      targets[idx*3+1] = ty
      targets[idx*3+2] = (Math.random() - 0.5) * 0.2

      const c = palette[Math.floor(Math.random() * palette.length)]
      colors[idx*3] = c.r; colors[idx*3+1] = c.g; colors[idx*3+2] = c.b
      filled++
    }

    const geo = new THREE.BufferGeometry()
    geo.setAttribute('position', new THREE.BufferAttribute(positions.slice(0, (OUTLINE_COUNT + filled) * 3), 3))
    geo.setAttribute('color',    new THREE.BufferAttribute(colors.slice(0, (OUTLINE_COUNT + filled) * 3), 3))
    geo.userData.targets = targets
    geo.userData.origins = positions.slice()  // 保存初始位置

    const mat = new THREE.PointsMaterial({
      size: 0.035,
      vertexColors: true,
      transparent: true,
      opacity: 0,           // 初始透明，phase1 时淡入
      sizeAttenuation: true,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    })

    return new THREE.Points(geo, mat)
  }, [heartPoint])

  // ── 缓动函数 ─────────────────────────────────────────────
  const easeInOutCubic = (t: number) =>
    t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2

  const easeOutExpo = (t: number) =>
    t === 1 ? 1 : 1 - Math.pow(2, -10 * t)

  useEffect(() => {
    const mount = mountRef.current
    if (!mount) return

    const w = mount.clientWidth
    const h = mount.clientHeight

    // ── Renderer ──────────────────────────────────────────
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true })
    renderer.setSize(w, h)
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2))
    renderer.setClearColor(0x000000, 0)
    mount.appendChild(renderer.domElement)

    const scene  = new THREE.Scene()
    const camera = new THREE.PerspectiveCamera(44, w / h, 0.1, 100)
    camera.position.z = 5.2

    // ── Lights ────────────────────────────────────────────
    scene.add(new THREE.AmbientLight(0xfff5ee, 1.0))

    const key = new THREE.DirectionalLight(0xffffff, 3.5)
    key.position.set(4, 7, 5)
    scene.add(key)

    const rim = new THREE.DirectionalLight(0xff9ab5, 2.5)
    rim.position.set(-5, -1, -3)
    scene.add(rim)

    const fill = new THREE.DirectionalLight(0xffeedd, 1.2)
    fill.position.set(0, -4, 6)
    scene.add(fill)

    const pt1 = new THREE.PointLight(0xff5577, 5.0, 14)
    pt1.position.set(-2, 1.5, 3.5)
    scene.add(pt1)

    const pt2 = new THREE.PointLight(0xffaa44, 4.0, 12)
    pt2.position.set(2.5, -1, 3)
    scene.add(pt2)

    const pt3 = new THREE.PointLight(0xffffff, 6.0, 10)
    pt3.position.set(0, 3, 2)
    scene.add(pt3)

    const pt4 = new THREE.PointLight(0xcc88ff, 2.5, 10)
    pt4.position.set(-3, -2, 1)
    scene.add(pt4)

    // ── Heart group（初始不可见，待入场完成后淡入）────────
    const heartGroup = new THREE.Group()
    heartGroup.rotation.z = 0
    heartGroup.position.y = 0.1
    heartGroup.visible = false   // 入场期间隐藏
    scene.add(heartGroup)

    const HEART_SCALE = 0.065

    const outerMat = new THREE.MeshPhongMaterial({
      color:    new THREE.Color('#CC3360'),
      emissive: new THREE.Color('#5A0A18'),
      emissiveIntensity: 1,
      specular: new THREE.Color('#ffffff'),
      shininess: 180,
      transparent: true,
      opacity: 0,
    })
    heartGroup.add(new THREE.Mesh(buildHeartGeo(HEART_SCALE), outerMat))

    const innerMat = new THREE.MeshPhongMaterial({
      color:    new THREE.Color('#FF8FAA'),
      emissive: new THREE.Color('#CC2255'),
      emissiveIntensity: 1,
      specular: new THREE.Color('#ffccdd'),
      shininess: 60,
      transparent: true,
      opacity: 0,
      side: THREE.BackSide,
    })
    heartGroup.add(new THREE.Mesh(buildHeartGeo(0.058), innerMat))

    const coreMat = new THREE.MeshPhongMaterial({
      color:    new THREE.Color('#FFB0C8'),
      emissive: new THREE.Color('#FF2244'),
      emissiveIntensity: 1,
      shininess: 0,
      transparent: true,
      opacity: 0,
      side: THREE.BackSide,
    })
    heartGroup.add(new THREE.Mesh(buildHeartGeo(0.048), coreMat))

    const specMat = new THREE.MeshPhongMaterial({
      color:    new THREE.Color('#ffffff'),
      emissive: new THREE.Color('#000000'),
      specular: new THREE.Color('#ffffff'),
      shininess: 800,
      transparent: true,
      opacity: 0,
    })
    heartGroup.add(new THREE.Mesh(buildHeartGeo(0.0655), specMat))

    // 目标 opacity 值（idle 状态下的最终值）
    const targetOpacities = [1, 0.45, 0.28, 0.10]

    // ── 轨道闪光粒子 ─────────────────────────────────────
    const sparkCount = 100
    const sPos = new Float32Array(sparkCount * 3)
    const sCol = new Float32Array(sparkCount * 3)
    const sparkColors: THREE.Color[] = [
      new THREE.Color('#FFD6E0'),
      new THREE.Color('#FFC0CB'),
      new THREE.Color('#FFAABB'),
      new THREE.Color('#ffffff'),
      new THREE.Color('#FFE4EC'),
    ]
    for (let i = 0; i < sparkCount; i++) {
      const theta = Math.random() * Math.PI * 2
      const phi   = Math.acos(2 * Math.random() - 1)
      const r     = 1.3 + Math.random() * 1.0
      sPos[i*3]   = r * Math.sin(phi) * Math.cos(theta)
      sPos[i*3+1] = r * Math.sin(phi) * Math.sin(theta)
      sPos[i*3+2] = r * Math.cos(phi)
      const c = sparkColors[Math.floor(Math.random() * sparkColors.length)]
      sCol[i*3] = c.r; sCol[i*3+1] = c.g; sCol[i*3+2] = c.b
    }
    const sparkGeo = new THREE.BufferGeometry()
    sparkGeo.setAttribute('position', new THREE.BufferAttribute(sPos, 3))
    sparkGeo.setAttribute('color',    new THREE.BufferAttribute(sCol, 3))
    const sparks = new THREE.Points(sparkGeo, new THREE.PointsMaterial({
      size: 0.022, vertexColors: true,
      transparent: true, opacity: 0, sizeAttenuation: true,
    }))
    scene.add(sparks)

    // ── 创建入场粒子 ─────────────────────────────────────
    const introParticles = createIntroParticles(HEART_SCALE)
    scene.add(introParticles)

    // ── 存储 refs ─────────────────────────────────────────
    sceneRef.current = {
      renderer, scene, camera, heartGroup,
      burstParticles: null, animFrame: 0,
      isBursting: false, burstStartTime: 0,
      mouseX: 0, mouseY: 0,
      lights: [pt1, pt2, pt3, pt4],
      sparks,
      introParticles,
      introStartTime: performance.now() / 1000,
      introPhase: 0,
    }

    // ── 动画主循环 ────────────────────────────────────────
    let time = 0
    let curRotY = 0
    let curRotX = 0

    const animate = () => {
      const ref = sceneRef.current
      if (!ref) return
      ref.animFrame = requestAnimationFrame(animate)
      time += 0.008

      const elapsed = performance.now() / 1000 - ref.introStartTime

      // ═══════════════════════════════════════════════════
      // 入场动画
      // ═══════════════════════════════════════════════════
      if (ref.introPhase < 3) {
        const ip = ref.introParticles
        if (!ip) { ref.introPhase = 3; return }

        const pos     = ip.geometry.getAttribute('position') as THREE.BufferAttribute
        const targets = ip.geometry.userData.targets as Float32Array
        const origins = ip.geometry.userData.origins as Float32Array
        const mat     = ip.material as THREE.PointsMaterial
        const count   = pos.count

        // ── Phase 0：短暂等待，粒子淡入 ──
        if (elapsed < PHASE1_START) {
          const t = elapsed / PHASE1_START
          mat.opacity = easeInOutCubic(t) * 0.9
          ref.introPhase = 0

        // ── Phase 1：lerp 飞向目标（心形轮廓/填充）──
        } else if (elapsed < PHASE1_END) {
          ref.introPhase = 1
          mat.opacity = 0.9

          // 归一化进度 [0,1]
          const raw = (elapsed - PHASE1_START) / (PHASE1_END - PHASE1_START)
          const t   = easeOutExpo(Math.min(raw, 1))

          for (let i = 0; i < count; i++) {
            // 每个粒子有稍微不同的延迟（按索引错开）
            const delay  = (i / count) * 0.3
            const localT = Math.max(0, Math.min((raw - delay) / (1 - delay * 0.5), 1))
            const lt     = easeOutExpo(localT)

            const ox = origins[i*3], oy = origins[i*3+1], oz = origins[i*3+2]
            const tx = targets[i*3], ty = targets[i*3+1], tz = targets[i*3+2]

            pos.setXYZ(
              i,
              ox + (tx - ox) * lt,
              oy + (ty - oy) * lt,
              oz + (tz - oz) * lt,
            )
          }
          pos.needsUpdate = true

          // 粒子大小随归位而增大（到位时更亮）
          mat.size = 0.025 + t * 0.025

        // ── Phase 2：粒子消融，实体心形淡入 ──
        } else if (elapsed < PHASE2_END) {
          ref.introPhase = 2

          const raw = (elapsed - PHASE1_END) / (PHASE2_END - PHASE1_END)
          const t   = easeInOutCubic(Math.min(raw, 1))

          // 粒子淡出
          mat.opacity = 0.9 * (1 - t)

          // 实体心形淡入
          if (!heartGroup.visible) heartGroup.visible = true
          heartGroup.children.forEach((obj, idx) => {
            const mesh = obj as THREE.Mesh
            const m    = mesh.material as THREE.MeshPhongMaterial
            if (m) m.opacity = targetOpacities[idx] * t
          })

          // 轨道闪光同步淡入
          ;(sparks.material as THREE.PointsMaterial).opacity = 0.7 * t

          // 从轮廓聚合位置微微缩放（聚合时偏小，完成后弹到正常）
          const scaleT = t < 0.7 ? (0.85 + t * 0.2) : (1.0 + Math.sin((t - 0.7) / 0.3 * Math.PI) * 0.05)
          heartGroup.scale.setScalar(scaleT)

        // ── Phase 3：入场完成，切换到 idle ──
        } else {
          if (ref.introPhase !== 3) {
            ref.introPhase = 3
            mat.opacity = 0
            ip.visible = false   // 彻底隐藏入场粒子

            // 确保实体最终 opacity 正确
            heartGroup.visible = true
            heartGroup.children.forEach((obj, idx) => {
              const mesh = obj as THREE.Mesh
              const m    = mesh.material as THREE.MeshPhongMaterial
              if (m) m.opacity = targetOpacities[idx]
            })
            ;(sparks.material as THREE.PointsMaterial).opacity = 0.7
          }
        }
      }

      // ═══════════════════════════════════════════════════
      // Idle 动画（入场完成后 & 未爆炸时）
      // ═══════════════════════════════════════════════════
      if (ref.introPhase === 3 && !ref.isBursting) {
        const targetY = time * 0.32 + ref.mouseX * 0.25
        const targetX = Math.sin(time * 0.25) * 0.10 + ref.mouseY * 0.15
        curRotY += (targetY - curRotY) * 0.05
        curRotX += (targetX - curRotX) * 0.05
        ref.heartGroup.rotation.y = curRotY
        ref.heartGroup.rotation.x = curRotX

        const breathe = 1 + Math.sin(time * 1.0) * 0.028
        ref.heartGroup.scale.setScalar(breathe)

        ref.lights[0].intensity = 5.0 + Math.sin(time * 1.8) * 2.0
        ref.lights[1].intensity = 4.0 + Math.cos(time * 1.4) * 1.5
        ref.lights[2].intensity = 6.0 + Math.sin(time * 2.1 + 1.0) * 2.5
        ref.lights[3].intensity = 2.5 + Math.cos(time * 0.9) * 1.0

        ref.lights[0].position.x = -2   + Math.sin(time * 0.7) * 1.0
        ref.lights[0].position.y =  1.5 + Math.cos(time * 0.5) * 0.5
        ref.lights[1].position.x =  2.5 + Math.cos(time * 0.6) * 1.0
        ref.lights[2].position.y =  3   + Math.sin(time * 0.8) * 0.8

        ref.sparks.rotation.y += 0.004
        ref.sparks.rotation.x += 0.0015
      }

      // ═══════════════════════════════════════════════════
      // 爆炸动画（原有功能）
      // ═══════════════════════════════════════════════════
      if (ref.isBursting) {
        const burstElapsed  = (Date.now() - ref.burstStartTime) / 1000
        const progress = Math.min(burstElapsed / 0.9, 1)
        const eased    = 1 - Math.pow(1 - progress, 3)

        ref.heartGroup.scale.setScalar(1 + eased * 0.7)

        ref.heartGroup.children.forEach((obj) => {
          const mesh = obj as THREE.Mesh
          const mat  = mesh.material as THREE.MeshPhongMaterial
          if (mat) {
            mat.transparent = true
            mat.opacity = Math.max(0, mat.opacity - eased * 0.04)
          }
        })

        ref.sparks.visible = false

        if (ref.burstParticles) {
          const bpos = ref.burstParticles.geometry.getAttribute('position') as THREE.BufferAttribute
          const vel  = ref.burstParticles.geometry.userData.velocities as Float32Array
          const bmat = ref.burstParticles.material as THREE.PointsMaterial
          for (let i = 0; i < bpos.count; i++) {
            bpos.setX(i, bpos.getX(i) + vel[i*3])
            bpos.setY(i, bpos.getY(i) + vel[i*3+1] - 0.0006 * burstElapsed * 60)
            bpos.setZ(i, bpos.getZ(i) + vel[i*3+2])
          }
          bpos.needsUpdate = true
          bmat.opacity = Math.max(0, 1 - eased * 0.9)
        }

        if (progress >= 1) {
          ref.isBursting = false
          onBurstComplete?.()
        }
      }

      renderer.render(scene, camera)
    }
    animate()

    const handleResize = () => {
      if (!mount || !sceneRef.current) return
      const w2 = mount.clientWidth
      const h2 = mount.clientHeight
      sceneRef.current.camera.aspect = w2 / h2
      sceneRef.current.camera.updateProjectionMatrix()
      sceneRef.current.renderer.setSize(w2, h2)
    }
    window.addEventListener('resize', handleResize)

    return () => {
      window.removeEventListener('resize', handleResize)
      if (sceneRef.current) {
        cancelAnimationFrame(sceneRef.current.animFrame)
        sceneRef.current.renderer.dispose()
      }
      if (mount.contains(renderer.domElement)) {
        mount.removeChild(renderer.domElement)
      }
    }
  }, [buildHeartGeo, createIntroParticles, onBurstComplete])

  // 同步鼠标
  useEffect(() => {
    if (!sceneRef.current) return
    sceneRef.current.mouseX = mouseX
    sceneRef.current.mouseY = mouseY
  }, [mouseX, mouseY])

  // 触发爆炸
  useEffect(() => {
    if (!burst || !sceneRef.current) return
    const ref = sceneRef.current
    ref.isBursting    = true
    ref.burstStartTime = Date.now()
    const bp = createBurstParticles()
    ref.scene.add(bp)
    ref.burstParticles = bp
  }, [burst, createBurstParticles])

  return (
    <div
      ref={mountRef}
      style={{ width: '100%', height: '100%', position: 'absolute', inset: 0 }}
    />
  )
}
